### EXERCÍCIOS (AULA 06 - ENTRADA DE DADOS)
<hr>

1. Elabore um algoritmo para calcular o salário líquido de um determinado funcionário. Você deve receber os seguintes valores: salário e imposto de renda. Com base nestes valores você deverá encontrar o valor do salário líquido (salário líquido = salário – imposto de renda) e mostrar na tela o resultado.
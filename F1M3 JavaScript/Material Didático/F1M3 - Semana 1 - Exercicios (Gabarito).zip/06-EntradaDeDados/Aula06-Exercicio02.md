### EXERCÍCIOS (AULA 06 - ENTRADA DE DADOS)
<hr>
2. Elabore um algoritmo para calcular o consumo de um determinado carro em um percurso qualquer. Você deve receber os seguintes valores: modelo do carro, número de quilômetros percorridos e número de litros de combustível gastos no percurso. Com base nestes valores você deverá encontrar o consumo (km/litro) do carro e mostrar na tela o resultado da seguinte forma:

  Exemplo: O consumo do carro ***gol*** é de ***18*** km/litro.
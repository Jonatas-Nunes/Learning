idade = 20;
altura = 1.75;
nome = "José";
pagou = true;

console.log("Os valores atribuídos as variáveis são: ");
console.log("Idade: ", idade);
console.log("Altura: ", altura);
console.log("Nome: ", nome);
console.log("Pagou: ", pagou);

console.log("Os tipos das variáveis são: ");
console.log("idade ", typeof (idade));
console.log("altura ", typeof (altura));
console.log("nome ", typeof (nome));
console.log("pagou ", typeof (pagou));


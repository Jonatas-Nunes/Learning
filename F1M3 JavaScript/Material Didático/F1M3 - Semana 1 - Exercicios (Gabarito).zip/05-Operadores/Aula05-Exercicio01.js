a = 1;
b = 2;
c = 3;
d = "3";
e = false;
f = true;

console.log("a + b ** c - c % 2: ", a + b ** c - c % 2);
console.log("b * (c / a - a): ", b * (c / a - a));
console.log("(c == d) != e: ", (c == d) != e);
console.log("(b >= a) == f: ", (b >= a) == f);
console.log("(c !== d) && (b % 1 == 0): ", (c !== d) && (b % 1 == 0));
console.log("e || (b > c || f): ", e || (b > c || f));

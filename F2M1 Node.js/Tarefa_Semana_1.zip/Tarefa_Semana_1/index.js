const prompt = require('prompt-sync')();
const customModule = require('../module.js')

let request;
var nome;
var rg;
var cpf;
var nascimento;

do {

    const novoCadastro = customModule.inserirCadastro();

    customModule.exibirCadastro(novoCadastro);

    customModule.addCadastro(novoCadastro);
    
    console.log(customModule.cadastros[0]);
    
} while (request !== 'sim');
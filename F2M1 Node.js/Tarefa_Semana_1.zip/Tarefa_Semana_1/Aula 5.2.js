// importando o módulo de conversor de temperatura
const converter = require('../Aula 5.1.js');

var tempF = 77;

var tempC = converter.FtoCelsius(tempF);


console.log(tempC);
